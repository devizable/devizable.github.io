# Excel Template V2 — standalone source build

Non-minified, tree-shaken build of **only** the Excel Template V2 dashboard
extension. No other extension in this repo is included in the output.

## Build

```bash
bun run build:standalone
# → dist-standalone/excel-template-v2/
```

Config used: `vite.standalone.config.ts` (`minify: false`, `cssMinify: false`,
`sourcemap: true`, Rollup `treeshake: "recommended"`).

## Output

```
dist-standalone/excel-template-v2/
  index.html                 # the extension (embed) entry
  config.html                # the configuration dialog entry
  excel-template-v2.trex     # manifest, points at http://localhost:8765/index.html
  tableau.extensions.1.latest.min.js
  assets/index.js  + .map    # embed bundle (readable)
  assets/config.js + .map    # config bundle (readable)
  assets/index2.js + .map    # shared chunk (React, ExcelJS, HyperFormula, UI)
  assets/index.css           # unminified design-system CSS
```

## Run locally

```bash
cd dist-standalone/excel-template-v2 && npx serve -l 8765 .
```

Then add `excel-template-v2.trex` to a Tableau dashboard. If you host it
elsewhere, edit the `<source-location><url>` in the .trex to match.

## Entry points

`standalone/excel-template-v2/embed.tsx` and `config.tsx` mount
`src/pages/ExcelTemplateEmbed.tsx` / `ExcelTemplateConfig.tsx` directly — no
react-router, no gallery pages, no other extension code.
